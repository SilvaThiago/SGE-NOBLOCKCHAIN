#!/bin/sh

QTD_TEST=100


rm result_train
rm result_classify
rm clean_result
rm -rd hw_info
mkdir hw_info

for counter in $(seq 1 $QTD_TEST); do
	python3 train.py >> result_train;
	sleep 5	
done
sed '/^Extracting/ d' < result_train > clean_result_train

for counter in $(seq 1 $QTD_TEST); do
	./get_gpu_temp.sh treino $counter &
	./get_gpu_usage.sh treino $counter &
	./get_cpu_temp.sh treino $counter &
	./get_cpu_usage.sh treino $counter &
	python3 train.py;
	$(ps -axf | grep ./get_gpu_temp | grep -v grep | awk '{print "kill " $1}')
	$(ps -axf | grep ./get_gpu_usage | grep -v grep | awk '{print "kill " $1}')
	$(ps -axf | grep ./get_cpu_temp | grep -v grep | awk '{print "kill " $1}')
	$(ps -axf | grep ./get_cpu_usage | grep -v grep | awk '{print "kill " $1}')
	sleep 5	
done

for counter in $(seq 1 $QTD_TEST); do
	python3 classify.py >> result_classify;
	sleep 5
done

sed '/^Extracting/ d' < result_classify > clean_result_classify

for counter in $(seq 1 $QTD_TEST); do
	./get_gpu_temp.sh classificacao $counter &
	./get_gpu_usage.sh classificacao $counter &
	./get_cpu_temp.sh classificacao $counter &
	./get_cpu_usage.sh classificacao $counter &
	python3 classify.py;
	$(ps -axf | grep ./get_gpu_temp | grep -v grep | awk '{print "kill " $1}')
	$(ps -axf | grep ./get_gpu_usage | grep -v grep | awk '{print "kill " $1}')
	$(ps -axf | grep ./get_cpu_temp | grep -v grep | awk '{print "kill " $1}')
	$(ps -axf | grep ./get_cpu_usage | grep -v grep | awk '{print "kill " $1}')
	sleep 5
done

./get_hw_infos.sh